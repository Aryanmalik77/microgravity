"""CLI module for nanobot."""
